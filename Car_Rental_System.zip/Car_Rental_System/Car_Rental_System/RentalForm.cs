﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Rental_System
{
    public partial class RentalForm : Form
    {
        public RentalForm()
        {
            InitializeComponent();
        }

        private void RentalForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'car_Rental_SystemDataSet2.CarRent' table. You can move, or remove it, as needed.
            this.carRentTableAdapter.Fill(this.car_Rental_SystemDataSet2.CarRent);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Car_Rental_System;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connectionString);

            try
            {
                conn.Open();
                string query = "INSERT INTO CarRent(CarId, CustomerID, CustomerName, RentFee, Date, DueDate ) VALUES('" + txbxcarid.Text + "', '" + txbxCustomerId.Text + "', '" + txbxName.Text + "', '" + txbxFee.Text + "', '"+dateTimePicker1.Text+"', '"+dateTimePicker2.Text+"')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                    MessageBox.Show(rowsAffected + " customer added successfully.");
                else
                    MessageBox.Show("Query execution failed.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not establish connection with database server. Please try again. Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }
    }
}
