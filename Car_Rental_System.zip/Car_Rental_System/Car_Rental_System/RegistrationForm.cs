﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Rental_System
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Car_Rental_System;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = new SqlConnection(connectionString);
            
            try
            {
                conn.Open();
                //string query = "UPDATE Registration SET Name='Asim' WHERE Id=1";
                string query = "INSERT INTO Registration(Name, CNIC, FatherName, Contact,Gender, Address) VALUES('" + txbxName.Text + "', '" + txbxCNIC.Text + "', '" + txbxFName.Text + "', '" + txbxContact.Text + "','" + txbxGender.Text + "', '" + txbxAddress.Text + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                    MessageBox.Show(rowsAffected + " customer added successfully.");
                else
                    MessageBox.Show("Query execution failed.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not establish connection with database server. Please try again. Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
        }
    }
}
